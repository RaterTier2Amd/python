import sys


#inHouseDatabase ={{"vehicalNo":"MH12 BF 1083","data" : ["Name" : "Kedar","MobileNumber" : "+919960550068"]} }

image_to_str="MH12MV1s322"
inHouseDatabase = {"MH12BF1083":{"data":"Kedar bhatkar,+918329171288,+9199600550068"},
                   "MH12MV1322":{"data":"Dummy,+919405432107,+919405432107"}}
if image_to_str in inHouseDatabase.keys():
    outList=str(inHouseDatabase[image_to_str]["data"]).split(",")
    print(outList[0])
else:
    print("KEY NOT FOUND")