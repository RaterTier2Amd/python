# Download the helper library from https://www.twilio.com/docs/python/install
from twilio.rest import Client


# Your Account Sid and Auth Token from twilio.com/console
#Rfrom_ = '+19714074077',
#Rto = '+917206844554'
#Raccount_sid = 'ACd6ee5a031453e24116ea9fe8b1093a32'
#Rauth_token = '8ad7b018b00daab74df93d7c8caeeb0c'
account_sid = 'ACaacfbbab928a5cf834dc7ca629d3b0bd'
auth_token = '1cdff415d7df09b2ab48d004f2c57008'
client = Client(account_sid, auth_token)

message = client.messages \
    .create(
         body='This is kedar the ship that made the Kessel Run in fourteen parsecs?',
         from_='+12672811697',
         to='+91832917129'
     )

print(message.status)
