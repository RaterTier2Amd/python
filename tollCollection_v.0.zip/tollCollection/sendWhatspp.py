# Download the helper library from https://www.twilio.com/docs/python/install
from twilio.rest import Client


# Your Account Sid and Auth Token from twilio.com/console
account_sid = 'ACaacfbbab928a5cf834dc7ca629d3b0bd'
auth_token = '1cdff415d7df09b2ab48d004f2c57008'
client = Client(account_sid, auth_token)

message = client.messages.create(
                              body='Hello there!',
                              from_='whatsapp:+14155238886',
                              to='whatsapp:+919960550068'
                          )

print(message.status)
