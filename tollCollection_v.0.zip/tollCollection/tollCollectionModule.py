import cv2
import numpy as np
import pytesseract
from PIL import Image
from pytesseract import image_to_string
from twilio.rest import Client

#Variable Definitions
account_sid = 'ACaacfbbab928a5cf834dc7ca629d3b0bd'
auth_token = '1cdff415d7df09b2ab48d004f2c57008'
imageList = ["emailKedar.png","Real.jpg","imageEmail.png","abcpqr.png","narrow.png","quote.png","bhavanaBike.png","product-250x250.png"] #["imageEmail.png","emailKedar.png"]
image_box="C:\\Users\\SONY\\AppData\\Local\\Programs\\Python\\Python35-32\\ImageBox\\"
client = Client(account_sid, auth_token)

#Functions
def scan_Database(image_to_str):
    inHouseDatabase = {"MH12 BF 1083": {"data": "Kedar bhatkar,+918329171288,SMS_ENABELED,'whatsapp:+9199600550068',WHATSAPP_ENABELED"},
                       "MH12MV1322":    {"data": "Gargi,+919405432107,SMS_ENABELE,'whatsapp:+919405432107',WHATSAPP_DISABLED"},
                       "MH 09 KN 1322":  {"data": "Snehal Narvekar,+919890636896,SMS_ENABELED,'whatsapp:+919890636896',WHATSAPP_ENABELED"},
                       "MH12LB059":     {"data": "Patil,+919999999999,SMS_ENABELED,'whatsapp:+919999999999',WHATSAPP_ENABELED"},
                       "MH 09 KN 132": {"data": "Sandip,+919960550068,SMS_DISABLED,'whatsapp:+919960550068',WHATSAPP_DISABLED"},
                       "MH12LB05":      {"data": "Dummy,+919999999999,SMS_DISABLED,'whatsapp:+919999999999',WHATSAPP_DISABLED"},
                       "MH12 BF 108":   {"data": "Dummy,+919999999999,SMS_DISABLED,'whatsapp:+919999999999',WHATSAPP_DISABLED"},
                       "MH12 AF 108":   {"data": "Dummy,+919999999999,SMS_DISABLED,'whatsapp:+919999999999',WHATSAPP_DISABLED"}}

    if image_to_str in inHouseDatabase.keys():
        outList = str(inHouseDatabase[image_to_str]["data"]).split(",")
        print("FOUND THE DETAILS IN THE DATABASE: "+outList[0])
        #client = Client(account_sid, auth_token)
        if outList[2] == "SMS_ENABELED":
            send_Sms(outList,client)
        else:
            print("SENDING SMS IS DISABLED FOR CURRENT USER")

        if outList[4] == "WHATSAPP_ENABELED":
            send_Whatsapp(outList,client)
        else:
            print("SENDING WHATSAPP IS DISABLED FOR CURRENT USER")

    else:
        print("NO INFORMATION AVAILABLE IN DATABASE")


def send_Sms(outListsms,client):
    message = client.messages \
        .create(
        body='Hello '+ outListsms[0] + 'Welcome to KhedShivapur Toll !!!!',
        from_='+12672811697',
        to=outListsms[1]
    )
    print("\nsent SMS to " + outListsms[0] + " On " + outListsms[1] + " \n")


def send_Whatsapp(outListwhtsapp,client):
    #tostr='whatsapp:'+ str(outListwhtsapp[2])
    #print(type(outListwhtsapp[3]))
    message = client.messages.create(
        body='Hello '+ outListwhtsapp[0] +' Welcome to KhedShivapur Toll  !!!!!',
        from_='whatsapp:+14155238886',
        to='whatsapp:+919960550068'
    )
    print("sent Whatsapp Message to " + outListwhtsapp[0] + " On " + outListwhtsapp[3])


def read_Image(img_path):
    # Read image with opencv
    img = cv2.imread(img_path)

    # Convert to gray
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Apply dilation and erosion to remove some noise
    kernel = np.ones((1, 1), np.uint8)
    img = cv2.dilate(img, kernel, iterations=1)
    img = cv2.erode(img, kernel, iterations=1)

    # Write image after removed noise
    cv2.imwrite( "removed_noise.png", img)

    #  Apply threshold to get image with only black and white
    #img = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 2)

    # Write the image after apply opencv to do some ...
    cv2.imwrite("thres.png", img)

    # Recognize text with tesseract for python
    result = pytesseract.image_to_string(Image.open( "thres.png"))

    return result


for i in  range(len(imageList)):
    print('\n------  Starting the process of image processing for -->  ' + imageList[i] + ' Image---\n\n' )
    image_to_str=read_Image(str(image_box + imageList[i]))
    print(">>   "+image_to_str + "   <<")
    scan_Database(image_to_str)
    print("\n\n------ Done -------\n\n")
    '''
    if image_to_str in inHouseDatabase.keys():
        outList = str(inHouseDatabase[image_to_str]["data"]).split(",")
        print("FOUND THE DETAILS IN THE DATABASE: "+outList[0])
        client = Client(account_sid, auth_token)
        sendSms(outList)
        sendWhatsapp(outList)
    else:
        print("NO INFORMATION AVAILABLE IN DATABASE")
    '''